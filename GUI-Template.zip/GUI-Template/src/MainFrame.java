/**
 * This class is example, where we use our gui template
 * @author hasselbaink
 * @version 1.0
 */
import java.awt.Component;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class MainFrame {
    private int width = 640, height = 480;
    
    private GUI gui;
    private JPanel mainPanel;
    private JLabel textLabel;
    public MainFrame(){
	gui.name = "Frame";
	gui.w = width;
	gui.h = height;
	gui.resizable = false;
	gui.closeOperation = gui.EXIT_ON_CLOSE;
	initComp();
	gui = new GUI();
	gui.add(mainPanel);
    }
    private void initComp(){
	mainPanel = new JPanel();
	mainPanel.setSize(width, height);
	mainPanel.setLocation(0, 0);
	mainPanel.setLayout(null);
	
		textLabel = new JLabel("Text");
		textLabel.setSize(100, 20);
		textLabel.setLocation(100, 100);
		addComp(textLabel);
    }
    /**
     * This method add gui component in main panel.
     * @param Component	Component, which we want add in frame
     */
    private void addComp(Component comp){
	mainPanel.add(comp);
    }
}
