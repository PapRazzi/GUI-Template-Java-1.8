/** 
 * This class is JFrame template for building swing frames
 * @author hasselbaink
 * @version 1.0
 */
import java.awt.LayoutManager;
import java.awt.LayoutManager;
import javax.swing.JFrame;

class GUI extends JFrame{
    protected static String name;
    protected static LayoutManager layout;
    protected static int w, h;
    protected static boolean resizable;
    protected static int closeOperation;
    protected GUI(){
	super(name);
	setLayout(layout);
	setSize(w, h);
	setResizable(resizable);
	setLocationRelativeTo(null);
	setDefaultCloseOperation(closeOperation);
	setVisible(true);
    }
}
